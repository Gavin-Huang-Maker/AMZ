$ErrorActionPreference = 'Stop'
$compilerPath = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compilerPath)) { $compilerPath = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
$sourcePath = Join-Path $PSScriptRoot 'DesktopStudio.cs'
$exePath = Join-Path $PSScriptRoot 'DesktopStudio.exe'
& $compilerPath /nologo /target:winexe /optimize+ "/out:$exePath" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll $sourcePath (Join-Path $PSScriptRoot 'DesktopPanels.cs')
if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
Write-Output "Built: $exePath"
